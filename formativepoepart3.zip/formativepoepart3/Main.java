/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */

package com.mycompany.formativepoepart3;

import com.mycompany.formativepart3poe.Message;
import javax.swing.JOptionPane;

/**
 * @author Awande Aphelele Cane, ST10447692
 * The Main class integrates the Login and Message classes, providing a JOptionPane-based
 * menu-driven interface for user registration, login, and messaging in QuickChat.
 */
public class Main {
    public static void main(String[] args) {
        Login login = new Login();
        Message message = new Message();

        // Registration
        String username = JOptionPane.showInputDialog(null, "Enter username:", "Register", JOptionPane.QUESTION_MESSAGE);
        String password = JOptionPane.showInputDialog(null, "Enter password:", "Register", JOptionPane.QUESTION_MESSAGE);
        String cellPhone = JOptionPane.showInputDialog(null, "Enter cell phone number (+27xxxxxxxxx):", "Register", JOptionPane.QUESTION_MESSAGE);
        String firstName = JOptionPane.showInputDialog(null, "Enter first name:", "Register", JOptionPane.QUESTION_MESSAGE);
        String lastName = JOptionPane.showInputDialog(null, "Enter last name:", "Register", JOptionPane.QUESTION_MESSAGE);

        String regResult = login.registerUser(username, password, cellPhone, firstName, lastName);
        JOptionPane.showMessageDialog(null, regResult, "Registration Status", JOptionPane.INFORMATION_MESSAGE);

        // Login
        username = JOptionPane.showInputDialog(null, "Enter username:", "Login", JOptionPane.QUESTION_MESSAGE);
        password = JOptionPane.showInputDialog(null, "Enter password:", "Login", JOptionPane.QUESTION_MESSAGE);

        String loginStatus = login.returnLoginStatus(username, password);
        JOptionPane.showMessageDialog(null, loginStatus, "Login Status", JOptionPane.INFORMATION_MESSAGE);
        if (!login.loginUser(username, password)) {
            JOptionPane.showMessageDialog(null, "You must log in to send messages.", "Login Failed", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Load stored messages from JSON
        message.loadStoredMessages();

        // Welcome and message limit
        JOptionPane.showMessageDialog(null, "Welcome to QuickChat.", "QuickChat", JOptionPane.INFORMATION_MESSAGE);
        String maxMessagesStr = JOptionPane.showInputDialog(null, "How many messages would you like to send?", "Message Limit", JOptionPane.QUESTION_MESSAGE);
        int maxMessages = Integer.parseInt(maxMessagesStr);
        int messagesEntered = 0;

        // Main menu
        while (true) {
            String[] options = {
                "Send Message", "Show Sender/Recipient", "Show Longest Message",
                "Search by Message ID", "Search by Recipient", "Delete by Message Hash",
                "Display Report", "Quit"
            };
            int choice = JOptionPane.showOptionDialog(null, "Select an option:", "QuickChat Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0: // Send Message
                    if (messagesEntered >= maxMessages) {
                        JOptionPane.showMessageDialog(null, "Message limit reached.", "Error", JOptionPane.ERROR_MESSAGE);
                        break;
                    }
                    String recipient = JOptionPane.showInputDialog(null, "Enter recipient number (+27xxxxxxxxx):", "Send Message", JOptionPane.QUESTION_MESSAGE);
                    String messageContent = JOptionPane.showInputDialog(null, "Enter message (≤250 characters):", "Send Message", JOptionPane.QUESTION_MESSAGE);
                    String[] sendOptions = {"Send", "Disregard", "Store"};
                    int sendChoice = JOptionPane.showOptionDialog(null, "Choose an action:", "Message Options",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, sendOptions, sendOptions[0]);
                    String result = message.sendMessage(recipient, messageContent, sendChoice);
                    JOptionPane.showMessageDialog(null, result, "Message Status", JOptionPane.INFORMATION_MESSAGE);
                    if (result.equals("Message successfully sent.")) {
                        messagesEntered++;
                    }
                    break;
                case 1: // Show Sender/Recipient
                    JOptionPane.showMessageDialog(null, message.displaySenderRecipient(), "Sender/Recipient", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 2: // Show Longest Message
                    JOptionPane.showMessageDialog(null, message.displayLongestMessage(), "Longest Message", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 3: // Search by Message ID
                    String messageId = JOptionPane.showInputDialog(null, "Enter message ID:", "Search by ID", JOptionPane.QUESTION_MESSAGE);
                    JOptionPane.showMessageDialog(null, message.searchByMessageId(messageId), "Search Result", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 4: // Search by Recipient
                    recipient = JOptionPane.showInputDialog(null, "Enter recipient number (+27xxxxxxxxx):", "Search by Recipient", JOptionPane.QUESTION_MESSAGE);
                    JOptionPane.showMessageDialog(null, message.searchByRecipient(recipient), "Search Result", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 5: // Delete by Message Hash
                    String messageHash = JOptionPane.showInputDialog(null, "Enter message hash:", "Delete by Hash", JOptionPane.QUESTION_MESSAGE);
                    JOptionPane.showMessageDialog(null, message.deleteByMessageHash(messageHash), "Delete Status", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 6: // Display Report
                    JOptionPane.showMessageDialog(null, message.displayReport(), "Sent Messages Report", JOptionPane.INFORMATION_MESSAGE);
                    break;
                case 7: // Quit
                    JOptionPane.showMessageDialog(null, "Total messages sent: " + message.returnTotalMessages(), "Summary", JOptionPane.INFORMATION_MESSAGE);
                    System.exit(0);
            }
        }
    }
}
