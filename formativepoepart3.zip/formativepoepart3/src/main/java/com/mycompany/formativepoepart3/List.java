package com.mycompany.formativepoepart3;

class List<T> {
}
