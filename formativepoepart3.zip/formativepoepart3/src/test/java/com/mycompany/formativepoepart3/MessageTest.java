/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.formativepoepart3;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;

/**
 * @author Awande Aphelele Cane, ST10447692
 * JUnit test class for the Message class, testing array population, message operations,
 * and report generation using provided test data.
 */
public class MessageTest {
    private Message message;
    private final String[] testMessages = {
        "Did you get the cake?",
        "Where are you? You are late! I have asked you to be on time.",
        "Yohoooo, I am at your gate.",
        "It is dinner time!",
        "Ok, I am leaving without you."
    };
    private final String[] testRecipients = {
        "+27834557896",
        "+27838884567",
        "+27834484567",
        "+27838884567", // Corrected to valid +27 format
        "+27838884567"
    };
    private final int[] testFlags = {0, 2, 1, 0, 2}; // 0=Sent, 1=Disregard, 2=Store

    @BeforeEach
    public void setUp() throws Exception {
        message = new Message();
        // Reset static fields
        Field sentMessagesField = Message.class.getDeclaredField("sentMessages");
        sentMessagesField.setAccessible(true);
        sentMessagesField.set(null, new ArrayList<>());

        Field disregardedMessagesField = Message.class.getDeclaredField("disregardedMessages");
        disregardedMessagesField.setAccessible(true);
        disregardedMessagesField.set(null, new ArrayList<>());

        Field storedMessagesField = Message.class.getDeclaredField("storedMessages");
        storedMessagesField.setAccessible(true);
        storedMessagesField.set(null, new ArrayList<>());

        Field messageHashesField = Message.class.getDeclaredField("messageHashes");
        messageHashesField.setAccessible(true);
        messageHashesField.set(null, new ArrayList<>());

        Field messageIdsField = Message.class.getDeclaredField("messageIds");
        messageIdsField.setAccessible(true);
        messageIdsField.set(null, new ArrayList<>());

        Field totalMessagesField = Message.class.getDeclaredField("totalMessagesSent");
        totalMessagesField.setAccessible(true);
        totalMessagesField.set(null, 0);

        // Delete JSON file to ensure clean state
        new File("messages.json").delete();

        // Populate arrays with test data
        for (int i = 0; i < testMessages.length; i++) {
            message.sendMessage(testRecipients[i], testMessages[i], testFlags[i]);
        }
        message.loadStoredMessages();
    }

    @Test
    public void testSentMessagesArray() {
        java.util.List<String> expected = Arrays.asList("Did you get the cake?", "It is dinner time!");
        assertEquals(expected, message.getSentMessages());
    }

    @Test
    public void testDisregardedMessagesArray() {
        java.util.List<String> expected = Arrays.asList("Yohoooo, I am at your gate.");
        assertEquals(expected, message.getDisregardedMessages());
    }

    @Test
    public void testStoredMessagesArray() {
        java.util.List<String> expected = Arrays.asList(
            "Where are you? You are late! I have asked you to be on time.",
            "Ok, I am leaving without you."
        );
        assertEquals(expected, message.getStoredMessages());
    }

    @Test
    public void testDisplayLongestMessage() {
        String expected = "Where are you? You are late! I have asked you to be on time.";
        assertEquals(expected, message.displayLongestMessage());
    }

    @Test
    public void testSearchByMessageId() {
        String messageId = message.getMessageIds().get(3); // Message 4
        String expected = "Recipient: +27838884567, Message: It is dinner time!";
        assertEquals(expected, message.searchByMessageId(messageId));
    }

    @Test
    public void testSearchByRecipient() {
        String recipient = "+27838884567";
        String expected = """
                          Where are you? You are late! I have asked you to be on time.
                          It is dinner time!
                          Ok, I am leaving without you.
                          """;
        assertEquals(expected, message.searchByRecipient(recipient));
    }

    @Test
    public void testDeleteByMessageHash() {
        String messageHash = message.getMessageHashes().get(1); // Message 2
        String expected = "Message \"Where are you? You are late! I have asked you to be on time.\" successfully deleted.";
        assertEquals(expected, message.deleteByMessageHash(messageHash));
        assertFalse(message.getStoredMessages().contains("Where are you? You are late! I have asked you to be on time."));
    }

    @Test
    public void testDisplayReport() {
        String report = message.displayReport();
        assertTrue(report.contains("Did you get the cake?"));
        assertTrue(report.contains("It is dinner time!"));
        assertFalse(report.contains("Yohoooo, I am at your gate."));
    }

    @Test
    public void testJsonFileReading() {
        try (FileReader reader = new FileReader("messages.json")) {
            JSONParser parser = new JSONParser();
            JSONArray jsonArray = (JSONArray) parser.parse(reader);
            assertEquals(2, jsonArray.size()); // Only stored messages (2, 5)
            JSONObject msg = (JSONObject) jsonArray.get(0);
            assertEquals("Where are you? You are late! I have asked you to be on time.", msg.get("Message"));
        } catch (IOException | org.json.simple.parser.ParseException e) {
            fail("Failed to read JSON file: " + e.getMessage());
        }
    }
}
