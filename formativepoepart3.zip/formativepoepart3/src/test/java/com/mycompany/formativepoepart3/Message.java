package com.mycompany.formativepoepart3;

class Message {

    void sendMessage(String testRecipient, String testMessage, int testFlag) {
    }

    void loadStoredMessages() {
    }

    Object getSentMessages() {
    }

    Object getDisregardedMessages() {
    }

    Object getStoredMessages() {
    }

    Object displayLongestMessage() {
    }

    Object getMessageIds() {
    }

    Object searchByMessageId(String messageId) {
    }

    Object searchByRecipient(String recipient) {
    }

    Object getMessageHashes() {
    }

    Object deleteByMessageHash(String messageHash) {
    }

    String displayReport() {
    }
}
