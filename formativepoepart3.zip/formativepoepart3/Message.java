/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/File.java to edit this template
 */
package com.mycompany.formativepoepart3;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.swing.JOptionPane;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Awande Aphelele Cane, ST10447692
 * The Message class manages message creation, validation, and storage for the QuickChat application.
 * It supports message ID generation, recipient validation, message hash creation, JSON storage,
 * and array-based operations for sent, disregarded, and stored messages.
 */
public class Message {
    private String messageId;
    private int messageNumber;
    private String recipient;
    private String messageContent;
    private String messageHash;
    private String sender = "+27712345678"; // Simulated sender for all messages
    private static List<String> sentMessages = new ArrayList<>();
    private static List<String> disregardedMessages = new ArrayList<>();
    private static List<String> storedMessages = new ArrayList<>();
    private static List<String> messageHashes = new ArrayList<>();
    private static List<String> messageIds = new ArrayList<>();
    private static int totalMessagesSent = 0;
    private static final String JSON_FILE = "messages.json";

    // Generates a random 10-digit message ID
    public boolean checkMessageID(String messageId) {
        if (messageId == null) return false;
        return messageId.matches("\\d{10}");
    }

    // Validates recipient cell number (+27 followed by 9 digits)
    public boolean checkRecipientCell(String recipient) {
        if (recipient == null) return false;
        String regex = "^\\+27\\d{9}$";
        return recipient.matches(regex);
    }

    // Validates message length (≤250 characters)
    public String checkMessageLength(String message) {
        if (message == null || message.trim().isEmpty()) return "Message cannot be null or empty.";
        if (message.length() > 250) {
            return "Message exceeds 250 characters by " + (message.length() - 250) + ", please reduce size.";
        }
        return "Message ready to send.";
    }

    // Creates message hash: first 2 digits of message ID, message number, first and last words
    public String createMessageHash(String messageId, int messageNumber, String messageContent) {
        if (messageId == null || messageContent == null || messageContent.trim().isEmpty()) {
            return "";
        }
        String[] words = messageContent.trim().split("\\s+");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        String firstTwoDigits = messageId.length() >= 2 ? messageId.substring(0, 2) : "00";
        return String.format("%s:%d:%s%s", firstTwoDigits, messageNumber, firstWord.toUpperCase(), lastWord.toUpperCase());
    }

    // Sends, disregards, or stores a message
    public String sendMessage(String recipient, String messageContent, int choice) {
        this.messageId = generateMessageId();
        this.messageNumber = totalMessagesSent + 1;
        this.recipient = recipient;
        this.messageContent = messageContent.trim();
        this.messageHash = createMessageHash(messageId, messageNumber, messageContent);

        String lengthCheck = checkMessageLength(messageContent);
        if (!lengthCheck.equals("Message ready to send.")) {
            return lengthCheck;
        }
        if (!checkRecipientCell(recipient)) {
            return "Cell phone number is incorrectly formatted or does not contain an international code.";
        }
        if (!checkMessageID(messageId)) {
            return "Invalid message ID.";
        }

        messageIds.add(messageId);
        messageHashes.add(messageHash);

        switch (choice) {
            case 0: // Send
                totalMessagesSent++;
                sentMessages.add(messageContent);
                JSONObject messageObj = createMessageObject();
                displayMessage(messageObj);
                return "Message successfully sent.";
            case 1: // Disregard
                disregardedMessages.add(messageContent);
                return "Message disregarded.";
            case 2: // Store
                storedMessages.add(messageContent);
                storeMessage(messageId, messageHash, recipient, messageContent);
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }

    // Generates a random 10-digit message ID
    private String generateMessageId() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }

    // Creates a JSONObject for the message
    private JSONObject createMessageObject() {
        JSONObject messageObj = new JSONObject();
        messageObj.put("MessageID", messageId);
        messageObj.put("MessageHash", messageHash);
        messageObj.put("Sender", sender);
        messageObj.put("Recipient", recipient);
        messageObj.put("Message", messageContent);
        return messageObj;
    }

    // Displays message details
    private void displayMessage(JSONObject message) {
        String display = String.format("MessageID: %s\nMessageHash: %s\nSender: %s\nRecipient: %s\nMessage: %s",
                message.get("MessageID"), message.get("MessageHash"), message.get("Sender"),
                message.get("Recipient"), message.get("Message"));
        JOptionPane.showMessageDialog(null, display, "Message Details", JOptionPane.INFORMATION_MESSAGE);
    }

    // Stores message in a JSON file
    public void storeMessage(String messageId, String messageHash, String recipient, String messageContent) {
        JSONObject messageObj = new JSONObject();
        messageObj.put("MessageID", messageId);
        messageObj.put("MessageHash", messageHash);
        messageObj.put("Sender", sender);
        messageObj.put("Recipient", recipient);
        messageObj.put("Message", messageContent);

        JSONArray messageArray = loadMessagesFromFile();
        messageArray.add(messageObj);

        try (FileWriter file = new FileWriter(JSON_FILE, false)) {
            file.write(messageArray.toJSONString());
            file.flush();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error storing message: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // Loads stored messages from JSON file into storedMessages array
    public void loadStoredMessages() {
        JSONArray messageArray = loadMessagesFromFile();
        storedMessages.clear(); // Clear existing stored messages
        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            storedMessages.add((String) messageObj.get("Message"));
        }
    }

    // Reads JSON file into a JSONArray
    private JSONArray loadMessagesFromFile() {
        JSONArray messageArray = new JSONArray();
        try (FileReader reader = new FileReader(JSON_FILE)) {
            JSONParser parser = new JSONParser();
            Object parsed = parser.parse(reader);
            if (parsed instanceof JSONArray) {
                messageArray = (JSONArray) parsed;
            }
        } catch (IOException | org.json.simple.parser.ParseException e) {
            // File doesn't exist or is invalid; return empty array
        }
        return messageArray;
    }

    // Displays sender and recipient of all sent messages
    public String displaySenderRecipient() {
        if (sentMessages.isEmpty()) {
            return "No sent messages.";
        }
        StringBuilder result = new StringBuilder();
        JSONArray messageArray = loadMessagesFromFile();
        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            if (sentMessages.contains(messageObj.get("Message"))) {
                result.append(String.format("Sender: %s, Recipient: %s\n",
                        messageObj.get("Sender"), messageObj.get("Recipient")));
            }
        }
        return result.length() > 0 ? result.toString() : "No matching sent messages found.";
    }

    // Displays the longest sent message
    public String displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            return "No sent messages.";
        }
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        return longest;
    }

    // Searches for a message by ID and returns recipient and message
    public String searchByMessageId(String messageId) {
        JSONArray messageArray = loadMessagesFromFile();
        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            if (messageId.equals(messageObj.get("MessageID"))) {
                return String.format("Recipient: %s, Message: %s",
                        messageObj.get("Recipient"), messageObj.get("Message"));
            }
        }
        return "Message ID not found.";
    }

    // Searches for all messages sent or stored to a recipient
    public String searchByRecipient(String recipient) {
        JSONArray messageArray = loadMessagesFromFile();
        StringBuilder result = new StringBuilder();
        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            if (recipient.equals(messageObj.get("Recipient")) &&
                (sentMessages.contains(messageObj.get("Message")) || storedMessages.contains(messageObj.get("Message")))) {
                result.append(messageObj.get("Message")).append("\n");
            }
        }
        return result.length() > 0 ? result.toString() : "No messages found for recipient.";
    }

    // Deletes a message by message hash
    public String deleteByMessageHash(String messageHash) {
        JSONArray messageArray = loadMessagesFromFile();
        JSONArray updatedArray = new JSONArray();
        boolean found = false;
        String deletedMessage = "";

        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            if (messageHash.equals(messageObj.get("MessageHash"))) {
                found = true;
                deletedMessage = (String) messageObj.get("Message");
                sentMessages.remove(deletedMessage);
                storedMessages.remove(deletedMessage);
                disregardedMessages.remove(deletedMessage);
                messageHashes.remove(messageHash);
                messageIds.remove(messageObj.get("MessageID"));
            } else {
                updatedArray.add(messageObj);
            }
        }

        if (found) {
            try (FileWriter file = new FileWriter(JSON_FILE, false)) {
                file.write(updatedArray.toJSONString());
                file.flush();
            } catch (IOException e) {
                return "Error updating JSON file: " + e.getMessage();
            }
            return String.format("Message \"%s\" successfully deleted.", deletedMessage);
        }
        return "Message hash not found.";
    }

    // Displays a report of all sent messages
    public String displayReport() {
        if (sentMessages.isEmpty()) {
            return "No sent messages.";
        }
        StringBuilder report = new StringBuilder("=== Sent Messages Report ===\n");
        JSONArray messageArray = loadMessagesFromFile();
        for (Object obj : messageArray) {
            JSONObject messageObj = (JSONObject) obj;
            if (sentMessages.contains(messageObj.get("Message"))) {
                report.append(String.format("MessageID: %s\nMessageHash: %s\nSender: %s\nRecipient: %s\nMessage: %s\n\n",
                        messageObj.get("MessageID"), messageObj.get("MessageHash"), messageObj.get("Sender"),
                        messageObj.get("Recipient"), messageObj.get("Message")));
            }
        }
        return report.toString();
    }

    // Returns total messages sent
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // Getters for testing
    public List<String> getSentMessages() {
        return sentMessages;
    }

    public List<String> getDisregardedMessages() {
        return disregardedMessages;
    }

    public List<String> getStoredMessages() {
        return storedMessages;
    }

    public List<String> getMessageHashes() {
        return messageHashes;
    }

    public List<String> getMessageIds() {
        return messageIds;
    }
}

